package com.mkamuy.phonefinder;
import java.util.UUID;
public final class Shared {
    public static final UUID SERVICE = UUID.fromString("1384bb6d-cb3c-4ad7-a0c1-4f6b82b7a137");
    public static final UUID COMMAND = UUID.fromString("5e323ccd-7895-4e16-9b52-21aa2f50101b");
    private Shared(){}
}
