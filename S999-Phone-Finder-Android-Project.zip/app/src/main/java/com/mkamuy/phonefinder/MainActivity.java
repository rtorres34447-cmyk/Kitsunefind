package com.mkamuy.phonefinder;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final Handler handler=new Handler(Looper.getMainLooper());
    BluetoothLeScanner scanner; ScanCallback scanCallback; BluetoothGatt gatt;
    TextView distanceText,statusText,trendText,dbmText;
    Button startPhone,startWatch,calibrate,ring,stopPhone;
    boolean scanning=false, discovered=false;
    int lastRssi=-100, referenceRssi=-59;
    double filteredRssi=Double.NaN, previousDistance=Double.NaN;
    long lastSeen=0;
    final Runnable staleCheck=new Runnable(){public void run(){if(scanning){if(System.currentTimeMillis()-lastSeen>6500){distanceText.setText("-- m");trendText.setText("SEARCHING");statusText.setText("Phone beacon not detected");}handler.postDelayed(this,1500);}}};
    int dp(float p){return (int)(getResources().getDisplayMetrics().density*p);}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        referenceRssi=getPreferences(0).getInt("one_meter_rssi",-59);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(12),dp(16),dp(16));root.setBackgroundColor(Color.rgb(13,15,18));
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
        addText(root,"MKAMUY / PHONE FINDER",16,Color.WHITE);
        addText(root,"Install the same APK on your S999 and your Galaxy S20 Ultra.",12,0xffaaaaaa);
        addText(root,"ON YOUR PHONE",12,0xffdddddd);
        startPhone=addButton(root,"START PHONE BEACON",()->startBeacon());
        stopPhone=addButton(root,"STOP PHONE BEACON",()->stopBeacon());
        addText(root,"ON YOUR S999 WATCH",12,0xffdddddd);
        startWatch=addButton(root,"FIND MY PHONE",()->startScan());
        distanceText=addText(root,"-- m",42,Color.WHITE);
        trendText=addText(root,"SEARCHING",16,0xffdddddd);
        dbmText=addText(root,"SIGNAL -- dBm",12,0xffaaaaaa);
        statusText=addText(root,"Not scanning",13,0xffdddddd);
        calibrate=addButton(root,"CALIBRATE AT 1 METRE",()->{if(!discovered){toast("Find the phone first");return;}referenceRssi=lastRssi;getPreferences(0).edit().putInt("one_meter_rssi",referenceRssi).apply();filteredRssi=Double.NaN;toast("Calibrated at 1 metre: "+referenceRssi+" dBm");});
        ring=addButton(root,"RING MY PHONE",()->ringPhone());
        addText(root,"Distance is an estimate from Bluetooth signal strength. Walls, pockets and your body affect it. Watch whether the reading goes up or down as you walk.",12,0xffaaaaaa);
        askPermissions();
    }
    TextView addText(LinearLayout parent,String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(10),0,dp(7));parent.addView(v);return v;}
    Button addButton(LinearLayout parent,String value,Runnable cb){Button v=new Button(this);v.setText(value);v.setAllCaps(false);v.setTextColor(Color.WHITE);v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff34383d));parent.addView(v,new LinearLayout.LayoutParams(-1,dp(51)));v.setOnClickListener(w->cb.run());return v;}
    void toast(String value){Toast.makeText(this,value,Toast.LENGTH_LONG).show();}
    String[] needed(){ArrayList<String> perms=new ArrayList<>();if(Build.VERSION.SDK_INT>=31){perms.add(Manifest.permission.BLUETOOTH_SCAN);perms.add(Manifest.permission.BLUETOOTH_CONNECT);perms.add(Manifest.permission.BLUETOOTH_ADVERTISE);}else{perms.add(Manifest.permission.ACCESS_FINE_LOCATION);}if(Build.VERSION.SDK_INT>=33)perms.add(Manifest.permission.POST_NOTIFICATIONS);return perms.toArray(new String[0]);}
    boolean hasPermissions(){for(String p:needed())if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED)return false;return true;}
    void askPermissions(){if(!hasPermissions())requestPermissions(needed(),11);}
    void startBeacon(){if(!hasPermissions()){askPermissions();toast("Grant Nearby devices then tap again");return;}
        BluetoothManager m=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);BluetoothAdapter a=m.getAdapter();if(a==null||!a.isEnabled()){toast("Enable Bluetooth");return;}if(!a.isMultipleAdvertisementSupported()){toast("Phone does not support BLE advertising");return;}
        try{Intent i=new Intent(this,BeaconService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);toast("Phone beacon started. Keep Bluetooth on.");}catch(Exception e){toast("Cannot start beacon: "+e.getMessage());}
    }
    void stopBeacon(){stopService(new Intent(this,BeaconService.class));toast("Phone beacon stopped");}
    void startScan(){if(scanning){stopScan();statusText.setText("Scanning stopped");return;}
        if(!hasPermissions()){askPermissions();toast("Grant Nearby devices then tap again");return;}
        BluetoothManager manager=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);BluetoothAdapter a=manager.getAdapter();if(a==null||!a.isEnabled()){toast("Enable Bluetooth");return;}
        scanner=a.getBluetoothLeScanner();if(scanner==null){toast("Bluetooth scanner unavailable");return;}
        discovered=false;lastSeen=0;filteredRssi=Double.NaN;previousDistance=Double.NaN;distanceText.setText("-- m");statusText.setText("Looking for phone beacon...");startWatch.setText("STOP SEARCHING");
        ScanFilter filter=new ScanFilter.Builder().setServiceUuid(new ParcelUuid(Shared.SERVICE)).build();
        ScanSettings settings=new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        scanCallback=new ScanCallback(){
            @Override public void onScanResult(int callbackType,ScanResult result){onFound(result);}
            @Override public void onBatchScanResults(List<ScanResult> results){for(ScanResult result:results)onFound(result);}
            @Override public void onScanFailed(int errorCode){runOnUiThread(()->{stopScan();statusText.setText("Scan failed: "+errorCode);});}
        };
        try{scanner.startScan(Collections.singletonList(filter),settings,scanCallback);scanning=true;handler.postDelayed(staleCheck,1500);}catch(SecurityException e){toast("Bluetooth permission required");}
    }
    void onFound(ScanResult result){if(android.os.Looper.myLooper()!=android.os.Looper.getMainLooper()){runOnUiThread(()->onFound(result));return;}int rssi=result.getRssi();lastRssi=rssi;lastSeen=System.currentTimeMillis();discovered=true;
        if(Double.isNaN(filteredRssi))filteredRssi=rssi;else filteredRssi=0.77*filteredRssi+0.23*rssi;
        // RSSI path loss estimate: 1m reference is user-calibrated; 2.4 = typical indoor path exponent.
        double metres=Math.pow(10.0,(referenceRssi-filteredRssi)/(10.0*2.4));metres=Math.max(0.1,Math.min(99,metres));
        distanceText.setText(String.format(Locale.US,"~ %.1f m",metres));dbmText.setText("SIGNAL "+rssi+" dBm  |  1m CAL "+referenceRssi+" dBm");
        if(Double.isNaN(previousDistance))trendText.setText("PHONE DETECTED");
        else if(metres<previousDistance*0.86)trendText.setText("GETTING CLOSER");
        else if(metres>previousDistance*1.14)trendText.setText("MOVING AWAY");
        else trendText.setText("DISTANCE APPROXIMATE");
        previousDistance=Double.isNaN(previousDistance)?metres:0.65*previousDistance+0.35*metres;
        statusText.setText("Phone found — walk slowly and watch the trend");
        // Retain the latest address; connection occurs only when the user taps Ring.
        device=result.getDevice();
    }
    BluetoothDevice device;
    void ringPhone(){if(!discovered||device==null){toast("Find the phone first");return;}
        if(!hasPermissions()){askPermissions();return;}
        statusText.setText("Connecting to ring phone...");
        try{if(gatt!=null){gatt.close();gatt=null;}gatt=device.connectGatt(this,false,new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int status,int state){if(status==BluetoothGatt.GATT_SUCCESS&&state==BluetoothProfile.STATE_CONNECTED){try{g.discoverServices();}catch(SecurityException ignored){}}else if(state==BluetoothProfile.STATE_DISCONNECTED){runOnUiThread(()->statusText.setText("Phone disconnected"));}}
            @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status!=BluetoothGatt.GATT_SUCCESS)return;BluetoothGattService service=g.getService(Shared.SERVICE);if(service==null){runOnUiThread(()->statusText.setText("Ring service unavailable"));return;}BluetoothGattCharacteristic command=service.getCharacteristic(Shared.COMMAND);if(command==null)return;
                try{if(Build.VERSION.SDK_INT>=33){g.writeCharacteristic(command,new byte[]{1},BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);}else{command.setValue(new byte[]{1});g.writeCharacteristic(command);}}catch(SecurityException ignored){}
            }
            @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int status){runOnUiThread(()->statusText.setText(status==BluetoothGatt.GATT_SUCCESS?"Ring command sent":"Ring failed: "+status));}
        });}catch(SecurityException e){toast("Bluetooth permission required");}
    }
    void stopScan(){scanning=false;handler.removeCallbacks(staleCheck);if(scanner!=null&&scanCallback!=null){try{scanner.stopScan(scanCallback);}catch(SecurityException ignored){}}scanCallback=null;startWatch.setText("FIND MY PHONE");}
    @Override protected void onDestroy(){stopScan();if(gatt!=null){try{gatt.close();}catch(Exception ignored){}}super.onDestroy();}
}
