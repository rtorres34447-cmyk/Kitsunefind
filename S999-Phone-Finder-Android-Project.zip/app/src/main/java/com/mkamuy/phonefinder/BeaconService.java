package com.mkamuy.phonefinder;

import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.content.pm.ServiceInfo;
import java.util.*;

public class BeaconService extends Service {
    static final String CHANNEL="finder_phone";
    static final String ACTION_STOP="com.mkamuy.phonefinder.STOP";
    BluetoothLeAdvertiser advertiser;
    AdvertiseCallback advertiseCallback;
    BluetoothGattServer server;
    MediaPlayer player;
    Handler handler=new Handler(Looper.getMainLooper());
    final Runnable stopRing=()->stopSound();
    @Override public void onCreate(){super.onCreate(); NotificationChannel c=new NotificationChannel(CHANNEL,"Phone finder",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("MKamuy phone beacon active").setContentText("Your watch can locate this phone").setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentIntent(open).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(23,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);else startForeground(23,n);
        startBeacon();return START_STICKY;
    }
    void startBeacon(){
        BluetoothManager m=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE); BluetoothAdapter a=m.getAdapter();
        if(a==null||!a.isEnabled()||!a.isMultipleAdvertisementSupported()){return;}
        try{
            if(server==null){
                server=m.openGattServer(this,new BluetoothGattServerCallback(){
                    @Override public void onCharacteristicWriteRequest(BluetoothDevice device,int requestId,BluetoothGattCharacteristic characteristic,boolean preparedWrite,boolean responseNeeded,int offset,byte[] value){
                        int status=BluetoothGatt.GATT_FAILURE;
                        if(Shared.COMMAND.equals(characteristic.getUuid())&&!preparedWrite&&offset==0&&value!=null&&value.length==1){
                            if(value[0]==1){handler.post(()->ring());status=BluetoothGatt.GATT_SUCCESS;}
                            if(value[0]==0){handler.post(()->stopSound());status=BluetoothGatt.GATT_SUCCESS;}
                        }
                        if(responseNeeded && server!=null)server.sendResponse(device,requestId,status,0,null);
                    }
                });
                if(server==null)return;
                BluetoothGattService s=new BluetoothGattService(Shared.SERVICE,BluetoothGattService.SERVICE_TYPE_PRIMARY);
                BluetoothGattCharacteristic command=new BluetoothGattCharacteristic(Shared.COMMAND,BluetoothGattCharacteristic.PROPERTY_WRITE,BluetoothGattCharacteristic.PERMISSION_WRITE);
                s.addCharacteristic(command);server.addService(s);
            }
            advertiser=a.getBluetoothLeAdvertiser();if(advertiser==null||advertiseCallback!=null)return;
            AdvertiseSettings settings=new AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH).setConnectable(true).build();
            AdvertiseData data=new AdvertiseData.Builder().addServiceUuid(new ParcelUuid(Shared.SERVICE)).setIncludeDeviceName(false).build();
            advertiseCallback=new AdvertiseCallback(){@Override public void onStartFailure(int errorCode){advertiseCallback=null;}};
            advertiser.startAdvertising(settings,data,advertiseCallback);
        }catch(SecurityException ignored){}
    }
    void ring(){stopSound();try{
        android.net.Uri uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if(uri==null)uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        player=MediaPlayer.create(this,uri);
        if(player!=null){player.setLooping(true);player.start();}
        handler.removeCallbacks(stopRing);handler.postDelayed(stopRing,20000);
    }catch(Exception ignored){}
    }
    void stopSound(){handler.removeCallbacks(stopRing);if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}}
    @Override public void onDestroy(){stopSound();try{if(advertiser!=null&&advertiseCallback!=null)advertiser.stopAdvertising(advertiseCallback);if(server!=null)server.close();}catch(SecurityException ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
