# MKamuy Phone Finder — S999 + Galaxy S20 Ultra

**One APK installed on both devices.** A BLE beacon on the phone is scanned by the S999 watch and its received signal strength (RSSI) is converted to a **rough, non-precision distance estimate in metres**. A GATT command can ring the phone for 20 seconds.

## Usage
1. Install the generated APK on **both** the Galaxy S20 Ultra and S999.
2. Enable Bluetooth and grant Nearby Devices permissions (and notifications on Android 13+).
3. On the **phone**, open the app and tap **START PHONE BEACON**. A foreground notification indicates it is running.
4. On the **watch**, open the app and tap **FIND MY PHONE**. The distance estimate appears when the phone is detected.
5. Place devices 1 metre apart, then tap **CALIBRATE AT 1 METRE** on the watch.
6. Walk around and use the increasing/decreasing trend. Tap **RING MY PHONE** to play an alarm on the phone for up to 20 seconds.

### Important limitations
- This is an **RSSI estimate**, not accurate ranging. It can be wrong by several metres or more, especially through walls or when devices are carried on the body. 0.1 m on screen does not imply 0.1 m accuracy.
- The phone must remain powered on with Bluetooth enabled and its beacon foreground service running. Some devices restrict Bluetooth advertising or stop background services to conserve battery.
- Bluetooth range is limited; **this is not a GPS tracker** and cannot find a phone far away.
- Neither internet nor a server is required. Beacons are not encrypted or authenticated; anyone using this known app UUID nearby could imitate a beacon and potentially trigger a ring on a phone running the app. Intended for personal local use and testing, not secure device pairing.
- Start scanning while the watch screen is on. BLE scan availability varies by S999 firmware.
- No changes to your existing S999 launcher or Kitsune Ears repositories.

## GitHub Actions
Upload `S999-Phone-Finder-Android-Project.zip` to the root of a separate repository, and create `.github/workflows/main.yml` using the accompanying workflow. Run the workflow and get the `S999-Phone-Finder-APK` artifact. The Android project is extracted from ZIP during the workflow.

This is **source code prepared for building**, not yet verified on the physical S999 and Galaxy S20 Ultra.
