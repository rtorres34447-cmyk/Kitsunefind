# KitsuneFind — S999 phone finder (v1.1 source package)

Install the **same APK** on the Samsung Galaxy S20 Ultra and the S999 watch. The phone advertises a Bluetooth Low Energy beacon and hosts a local ring command. The S999 scans the beacon and uses signal strength (RSSI) to estimate distance in **metres**.

## On the phone
1. Turn Bluetooth on. Open **MKamuy Phone Finder**.
2. Allow Nearby devices and notifications when prompted.
3. Tap **START PHONE BEACON**. Leave its ongoing foreground notification active. Disable aggressive battery optimisation if the phone suspends the service.

## On the S999
1. Turn Bluetooth on, install and open the same APK, grant Nearby devices.
2. Tap **FIND MY PHONE**. Watch for a signal reading (dBm) and estimated distance in metres.
3. Set the devices **1 metre apart** in the open, tap **CALIBRATE AT 1 METRE**.
4. Move slowly; watch **GETTING CLOSER** / **MOVING AWAY**. Tap **RING MY PHONE** to send a local Bluetooth command (about 20 seconds of sound).

## Limitations
- The metres value is a **rough signal-derived estimate**, potentially wrong by several metres or more. It is not true precise range measurement, and walls/body orientation substantially affect it. This device pair has no confirmed UWB capability.
- Works within Bluetooth range only, with the phone powered on, Bluetooth enabled and beacon service started; no internet required.
- BLE beacon and GATT ring protocol are **not paired/authenticated**, so this is a personal prototype, not a secure anti-theft system. It could detect another device running the same beacon.
- Automatic always-on phone beacon, robust device authentication, background watch scanning and persistent pairing are not implemented. Real-device testing is required.
- The APK has not been compiled or tested in this environment; GitHub Actions compiles it.

## GitHub upload
1. Upload `Kitsunefind-Android-Project.zip` to the repository **root**, not a subfolder and not extracted.
2. Add `.github/workflows/main.yml` with the supplied workflow.
3. Go to **Actions → Build Kitsunefind APK → Run workflow** on branch `main`.
4. Download the `Kitsunefind-APK` artifact from a successful run and install its APK on both devices.

The ZIP directly contains `settings.gradle`, `build.gradle`, `gradle.properties` and `app/` — **no enclosing directory**. Neither S999 launcher nor Kitsune Ears is modified.
